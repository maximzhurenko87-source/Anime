const START_TEAM_ENERGY = 3;
const MAX_TEAM_ENERGY = 6;
const SAVE_KEY = "neonMuseSaveV04";

const themes = [
  {
    id: "standard",
    name: "Стандартная",
    description: "Неон, фиолетовый и розовый.",
    a: "#ff4fd8",
    b: "#7c5cff"
  },
  {
    id: "black-red",
    name: "Чёрно-красная",
    description: "Тёмная агрессивная тема.",
    a: "#050505",
    b: "#ff1f3d"
  },
  {
    id: "ocean",
    name: "Океан",
    description: "Синий, голубой и холодный свет.",
    a: "#06131f",
    b: "#39d5ff"
  },
  {
    id: "sakura",
    name: "Сакура",
    description: "Мягкая розовая атмосфера.",
    a: "#1a0f18",
    b: "#ff8fcf"
  },
  {
    id: "emerald",
    name: "Изумруд",
    description: "Зелёный кибер-сад.",
    a: "#061411",
    b: "#35f3a5"
  },
  {
    id: "royal",
    name: "Королевская",
    description: "Золото, ночь и фиолетовый.",
    a: "#0d0a18",
    b: "#ffd76d"
  }
];

const baseCards = [
  {
    id: "nell-tu-home-passion",
    name: "Нелл Ту",
    icon: "💜",
    image: "assets/cards/nell-tu-domashnie-strasti.jpeg",
    rarity: "sr",
    role: "support",
    subRole: "control",
    series: "Нелл Ту",
    line: "Домашние страсти",
    border: "purple",
    atkStat: 70,
    hpStat: 170,
    defStat: 30,
    cost: 3,
    attack: 7,
    shield: 3,
    heal: 0,
    draw: 0,
    normalAttackName: "Обычная атака",
    skillName: "Спокойствие",
    skillDamage: 45,
    ultimateName: "Хочу ещё",
    ultimateDamage: 65,
    ultimateEffect: "Запрещает 1 ход противнику и даёт команде союзника дополнительный ход.",
    text: "SR-карта линейки «Домашние страсти». Навык наносит 45 урона. Ульта наносит 65 урона и пропускает ход противника."
  },
  {
    id: "yoruichi-wet-shunpo",
    name: "Йоруичи Шихоин - Мокрый Шунпо",
    icon: "⚡",
    image: "assets/cards/yoruichi-mokryi-shunpo.jpg",
    rarity: "ssr",
    role: "dps",
    subRole: "support",
    series: "Йоруичи Шихоин",
    line: "Пляж",
    border: "gold",
    atkStat: 90,
    hpStat: 230,
    defStat: 50,
    cost: 4,
    attack: 9,
    shield: 5,
    heal: 0,
    draw: 0,
    normalAttackName: "Базовая атака",
    skillName: "Мокрый Шунпо",
    skillDamage: 0,
    skillEffectText: "Повышает свою атаку на 60% на 2 хода и с вероятностью 40% уклоняется от следующей атаки противника. «Пока ты моргаешь — она уже на тебе.»",
    ultimateName: "Солнечный Тайфун",
    ultimateDamage: 120,
    ultimateEffect: "Наносит высокий AoE-урон всем противникам, сильно повышает свою атаку и скорость на 3 хода и накладывает дебафф «Ослепление Солнцем»: враги 2 хода получают повышенный урон и сниженную точность.",
    text: "SSR-карта линейки «Пляж». Легендарная золотая карточка с высоким уроном, усилением атаки и скоростью, а также дебаффом «Ослепление Солнцем»."
  },
  {
    id: "raiden-deep-absorption",
    name: "Райден Сёгун",
    icon: "⚡",
    image: "assets/cards/raiden-deep-absorption.jpg",
    rarity: "ssrplus",
    role: "dps",
    subRole: "control",
    series: "Райден Сёгун",
    line: "Глубокое Поглощение",
    border: "mythic",
    atkStat: 95,
    hpStat: 245,
    defStat: 45,
    cost: 4,
    attack: 10,
    shield: 4,
    heal: 0,
    draw: 0,
    normalAttackName: "Базовая атака",
    skillName: "Глубокий Захват",
    skillDamage: 55,
    skillEffectText: "Наносит 55 урона одному противнику, повышает свою атаку на 50% на 2 хода. С 40% шансом накладывает дебафф «Задыхающийся» — противник пропускает следующий ход.",
    ultimateName: "Божественный Глоток Вечности",
    ultimateDamage: 85,
    ultimateEffect: "Наносит 85 урона одному противнику, повышает свою атаку на 70% на 3 хода и накладывает дебафф «Покорность Вечности»: цель получает +60% входящего урона и теряет 40% защиты на 3 хода. С 50% шансом станит цель на 1 ход.",
    text: "SSR+-карта линейки «Глубокое Поглощение». Мифическая карточка с красной окантовкой, переливающейся золотым. Делает сильный упор на одиночный урон, самоусиление и жёсткие дебаффы."
  },
  {
    id: "sakura-strike",
    name: "Сакура: Неоновый удар",
    icon: "🌸",
    rarity: "common",
    cost: 1,
    attack: 4,
    shield: 0,
    heal: 0,
    draw: 0,
    text: "Наносит 4 урона сопернице."
  },
  {
    id: "luna-guard",
    name: "Луна: Лунный щит",
    icon: "🌙",
    rarity: "common",
    cost: 1,
    attack: 0,
    shield: 5,
    heal: 0,
    draw: 0,
    text: "Даёт 5 щита до следующего хода."
  },
  {
    id: "rei-focus",
    name: "Рэй: Фокус",
    icon: "✨",
    rarity: "common",
    cost: 0,
    attack: 1,
    shield: 1,
    heal: 0,
    draw: 1,
    text: "Малый эффект и добор 1 карты."
  },
  {
    id: "mika-combo",
    name: "Мика: Комбо",
    icon: "🎧",
    rarity: "rare",
    cost: 2,
    attack: 7,
    shield: 0,
    heal: 0,
    draw: 0,
    text: "Сильная атака за 2 энергии."
  },
  {
    id: "yuki-heal",
    name: "Юки: Перезагрузка",
    icon: "❄️",
    rarity: "rare",
    cost: 1,
    attack: 0,
    shield: 2,
    heal: 4,
    draw: 0,
    text: "Лечит 4 HP и даёт 2 щита."
  },
  {
    id: "nami-wave",
    name: "Нами: Волна",
    icon: "🌊",
    rarity: "rare",
    cost: 2,
    attack: 4,
    shield: 4,
    heal: 0,
    draw: 0,
    text: "Баланс атаки и защиты."
  },
  {
    id: "eve-trick",
    name: "Иви: Трюк",
    icon: "🃏",
    rarity: "epic",
    cost: 1,
    attack: 2,
    shield: 0,
    heal: 0,
    draw: 2,
    text: "Наносит 2 урона и добирает 2 карты."
  },
  {
    id: "aria-burst",
    name: "Ария: Вспышка",
    icon: "💫",
    rarity: "epic",
    cost: 3,
    attack: 10,
    shield: 0,
    heal: 0,
    draw: 0,
    text: "Мощная редкая карта."
  },
  {
    id: "ruby-queen",
    name: "Руби: Чёрная королева",
    icon: "♦️",
    rarity: "legendary",
    cost: 3,
    attack: 8,
    shield: 4,
    heal: 0,
    draw: 1,
    text: "Легендарный баланс атаки, защиты и добора."
  },
  {
    id: "astra-nova",
    name: "Астра: Нова",
    icon: "🌌",
    rarity: "legendary",
    cost: 3,
    attack: 12,
    shield: 0,
    heal: 0,
    draw: 0,
    text: "Очень сильная финишная атака."
  }
];

const rarityNames = {
  common: "Common",
  rare: "Rare",
  epic: "Epic",
  legendary: "Legendary",
  sr: "SR",
  ssr: "SSR",
  ssrplus: "SSR+"
};

const rarityWeights = [
  ["common", 53],
  ["rare", 27],
  ["epic", 12],
  ["legendary", 3],
  ["sr", 2],
  ["ssr", 2],
  ["ssrplus", 1]
];

const enemies = [
  "Rival Muse",
  "Crimson Idol",
  "Night Diva",
  "Velvet Star"
];

let save = loadSave();
let state = {};

const els = {
  ageGate: document.querySelector("#ageGate"),
  enterGameBtn: document.querySelector("#enterGameBtn"),
  quickNewBattleBtn: document.querySelector("#quickNewBattleBtn"),
  newGameBtn: document.querySelector("#newGameBtn"),
  restartBtn: document.querySelector("#restartBtn"),

  miniAvatar: document.querySelector("#miniAvatar"),
  homePlayerName: document.querySelector("#homePlayerName"),
  homePlayerDesc: document.querySelector("#homePlayerDesc"),
  homeOwnedCount: document.querySelector("#homeOwnedCount"),
  homeRarityLine: document.querySelector("#homeRarityLine"),

  gemsText: document.querySelector("#gemsText"),
  rollGachaBtn: document.querySelector("#rollGachaBtn"),
  gachaResult: document.querySelector("#gachaResult"),

  collectionGrid: document.querySelector("#collectionGrid"),
  rarityFilter: document.querySelector("#rarityFilter"),

  profileAvatar: document.querySelector("#profileAvatar"),
  profileName: document.querySelector("#profileName"),
  profileDescription: document.querySelector("#profileDescription"),
  profileAchievement: document.querySelector("#profileAchievement"),
  profileTotalCards: document.querySelector("#profileTotalCards"),
  profileRarityStats: document.querySelector("#profileRarityStats"),
  profileAvatarName: document.querySelector("#profileAvatarName"),
  avatarPicker: document.querySelector("#avatarPicker"),

  themeGrid: document.querySelector("#themeGrid"),
  resetProgressBtn: document.querySelector("#resetProgressBtn"),

  cardPreviewModal: document.querySelector("#cardPreviewModal"),
  closeCardPreviewBtn: document.querySelector("#closeCardPreviewBtn"),
  previewVisual: document.querySelector("#previewVisual"),
  previewRarity: document.querySelector("#previewRarity"),
  previewName: document.querySelector("#previewName"),
  previewSeries: document.querySelector("#previewSeries"),
  previewLine: document.querySelector("#previewLine"),
  previewStatIcons: document.querySelector("#previewStatIcons"),
  previewAbilityList: document.querySelector("#previewAbilityList"),
  previewText: document.querySelector("#previewText"),

  resultModal: document.querySelector("#resultModal"),
  resultTitle: document.querySelector("#resultTitle"),
  resultText: document.querySelector("#resultText"),
  duelPicker: document.querySelector("#duelPicker"),
  squadLeadName: document.querySelector("#squadLeadName"),

  combatRound: document.querySelector("#combatRound"),
  combatTurn: document.querySelector("#combatTurn"),
  combatEnergy: document.querySelector("#combatEnergy"),
  combatBigBadge: document.querySelector("#combatBigBadge"),
  combatLog: document.querySelector("#combatLog"),

  playerCombatCard: document.querySelector("#playerCombatCard"),
  enemyCombatCard: document.querySelector("#enemyCombatCard"),
  playerCombatArt: document.querySelector("#playerCombatArt"),
  enemyCombatArt: document.querySelector("#enemyCombatArt"),
  playerCombatRole: document.querySelector("#playerCombatRole"),
  enemyCombatRole: document.querySelector("#enemyCombatRole"),
  playerCombatName: document.querySelector("#playerCombatName"),
  enemyCombatName: document.querySelector("#enemyCombatName"),
  playerStatusBadge: document.querySelector("#playerStatusBadge"),
  enemyStatusBadge: document.querySelector("#enemyStatusBadge"),

  playerCombatHpFill: document.querySelector("#playerCombatHpFill"),
  enemyCombatHpFill: document.querySelector("#enemyCombatHpFill"),
  playerCombatHp: document.querySelector("#playerCombatHp"),
  enemyCombatHp: document.querySelector("#enemyCombatHp"),
  playerCombatMaxHp: document.querySelector("#playerCombatMaxHp"),
  enemyCombatMaxHp: document.querySelector("#enemyCombatMaxHp"),
  playerCombatAtk: document.querySelector("#playerCombatAtk"),
  playerCombatDef: document.querySelector("#playerCombatDef"),
  enemyCombatDef: document.querySelector("#enemyCombatDef"),
  playerCombatUlt: document.querySelector("#playerCombatUlt"),
  enemyCombatUlt: document.querySelector("#enemyCombatUlt"),

  basicAttackBtn: document.querySelector("#basicAttackBtn"),
  skillBtn: document.querySelector("#skillBtn"),
  ultimateBtn: document.querySelector("#ultimateBtn"),
  guardBtn: document.querySelector("#guardBtn")
};

function defaultSave() {
  return {
    playerName: "Игрок",
    description: "Начинающий коллекционер неоновых карт.",
    achievement: "Первый вход",
    gems: 1200,
    theme: "standard",
    selectedBattleCardId: "nell-tu-home-passion",
    avatarCardId: "sakura-strike",
    owned: {
      "sakura-strike": 1,
      "luna-guard": 1,
      "rei-focus": 1,
      "mika-combo": 1,
      "nell-tu-home-passion": 1,
      "yoruichi-wet-shunpo": 1,
      "raiden-deep-absorption": 1
    }
  };
}

function loadSave() {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return defaultSave();
    const loaded = { ...defaultSave(), ...JSON.parse(raw) };
    loaded.owned = { ...defaultSave().owned, ...(loaded.owned || {}) };
    if (!loaded.owned["nell-tu-home-passion"]) {
      loaded.owned["nell-tu-home-passion"] = 1;
    }
    if (!loaded.owned["yoruichi-wet-shunpo"]) {
      loaded.owned["yoruichi-wet-shunpo"] = 1;
    }
    if (!loaded.owned["raiden-deep-absorption"]) {
      loaded.owned["raiden-deep-absorption"] = 1;
    }
    if (!loaded.selectedBattleCardId || !loaded.owned[loaded.selectedBattleCardId]) {
      loaded.selectedBattleCardId = loaded.owned["nell-tu-home-passion"]
        ? "nell-tu-home-passion"
        : (loaded.owned["yoruichi-wet-shunpo"] ? "yoruichi-wet-shunpo" : Object.keys(loaded.owned)[0]);
    }
    return loaded;
  } catch {
    return defaultSave();
  }
}

function saveProgress() {
  localStorage.setItem(SAVE_KEY, JSON.stringify(save));
}

function getCard(id) {
  return baseCards.find((card) => card.id === id) || baseCards[0];
}

function ownedCards() {
  return baseCards
    .filter((card) => save.owned[card.id] > 0)
    .map((card) => ({ ...card, copies: save.owned[card.id] }));
}

function rarityStats() {
  const stats = { common: 0, rare: 0, epic: 0, legendary: 0, sr: 0, ssr: 0, ssrplus: 0 };
  Object.entries(save.owned).forEach(([cardId, count]) => {
    const card = getCard(cardId);
    stats[card.rarity] += count;
  });
  return stats;
}

function totalCards() {
  return Object.values(save.owned).reduce((sum, count) => sum + count, 0);
}


function duelEligibleCards() {
  return ownedCards().filter((card) => Boolean(card.atkStat));
}

function getSelectedBattleCard() {
  const fallback = getCard("nell-tu-home-passion");
  const selected = getCard(save.selectedBattleCardId || fallback.id);
  if (save.owned[selected.id] > 0) return selected;

  const firstAvailable = duelEligibleCards()[0] || fallback;
  save.selectedBattleCardId = firstAvailable.id;
  saveProgress();
  return firstAvailable;
}

function getRoleLabel(role, subRole = "") {
  const roleMap = {
    dps: "DPS",
    support: "Support",
    control: "Control",
    healer: "Healer",
    tank: "Tank",
    fighter: "Fighter"
  };

  const main = roleMap[role] || role || "Fighter";
  const sub = roleMap[subRole] || subRole || "";
  return sub ? `${main} / ${sub}` : main;
}

function getBorderClass(card) {
  if (card.border === "purple") return "purple-border";
  if (card.border === "gold") return "gold-border";
  if (card.border === "mythic") return "mythic-border";
  return "";
}

function getLineClass(card) {
  if (card.line === "Домашние страсти") return "line-animated";
  if (card.line === "Пляж") return "line-animated-beach";
  if (card.line === "Глубокое Поглощение") return "line-animated-deep";
  return "";
}

function buildFighterFromCard(card, team) {
  const hp = card.hpStat || 150;
  const atk = card.atkStat || Math.max(35, (card.attack || 5) * 10);
  const def = card.defStat || Math.max(10, (card.shield || 2) * 5);

  return {
    id: `${team}-${card.id}`,
    team,
    cardId: card.id,
    name: card.name,
    icon: card.icon,
    image: card.image,
    role: card.role || "fighter",
    subRole: card.subRole || "",
    maxHp: hp,
    hp,
    atk,
    def,
    shield: 0,
    ult: 0,
    skipTurns: 0,
    alive: true,
    basicName: card.normalAttackName || "Обычная атака",
    skillName: card.skillName || "Навык",
    ultimateName: card.ultimateName || "Ульта",
    skillDamage: card.skillDamage || Math.round(atk * 0.85),
    ultimateDamage: card.ultimateDamage || Math.round(atk * 1.25),
    atkBuffValue: 0,
    atkBuffTurns: 0,
    dodgeChance: 0,
    exposedTurns: 0,
    exposedMultiplier: 0,
    defDownTurns: 0,
    defDownValue: 0,
    blindTurns: 0,
    hasteTurns: 0
  };
}

function createEnemyFighter() {
  return {
    id: "enemy-crimson-rival",
    team: "enemy",
    cardId: "enemy-crimson-rival",
    name: "Crimson Rival",
    icon: "🦇",
    image: "",
    role: "dps",
    subRole: "control",
    maxHp: 150,
    hp: 150,
    atk: 55,
    def: 20,
    shield: 0,
    ult: 0,
    skipTurns: 0,
    alive: true,
    basicName: "Когти ревности",
    skillName: "Алый выпад",
    ultimateName: "Ночная вспышка",
    skillDamage: 42,
    ultimateDamage: 70,
    atkBuffValue: 0,
    atkBuffTurns: 0,
    dodgeChance: 0,
    exposedTurns: 0,
    exposedMultiplier: 0,
    defDownTurns: 0,
    defDownValue: 0,
    blindTurns: 0,
    hasteTurns: 0
  };
}

function startGame() {
  const chosenCard = getSelectedBattleCard();

  state = {
    round: 1,
    turn: "player",
    energy: START_TEAM_ENERGY,
    gameOver: false,
    extraTurnReady: false,
    player: buildFighterFromCard(chosenCard, "player"),
    enemy: createEnemyFighter()
  };

  els.resultModal.classList.add("hidden");
  renderBattlePrep();
  logCombat(`Новая дуэль началась. На арену выходит ${chosenCard.name}.`);
  renderBattle();
}

function effectiveAtk(unit) {
  return Math.round(unit.atk * (1 + (unit.atkBuffValue || 0)));
}

function effectiveDef(unit) {
  const reduction = unit.defDownTurns > 0 ? (unit.defDownValue || 0) : 0;
  return Math.max(0, Math.round(unit.def * (1 - reduction)));
}

function spendEnergy(cost) {
  if (state.energy < cost) return false;
  state.energy -= cost;
  return true;
}

function gainUlt(unit, amount) {
  unit.ult = Math.min(100, unit.ult + amount);
}

function attemptHit(attacker, target, sourceText) {
  if (attacker.blindTurns > 0 && Math.random() < 0.35) {
    logCombat(`${attacker.name} промахивается: «Ослепление Солнцем» сбивает точность.`);
    return false;
  }

  if (target.dodgeChance > 0 && Math.random() < target.dodgeChance) {
    target.dodgeChance = 0;
    logCombat(`${target.name} уклоняется от атаки «${sourceText}».`);
    return false;
  }

  return true;
}

function calculateDamage(rawDamage, target) {
  const exposureMultiplier = target.exposedTurns > 0 ? (1 + (target.exposedMultiplier || 0.25)) : 1;
  const amplifiedRaw = Math.round(rawDamage * exposureMultiplier);
  const minimum = amplifiedRaw * 0.2;
  const afterDef = amplifiedRaw - effectiveDef(target);
  return Math.max(1, Math.round(Math.max(minimum, afterDef)));
}

function dealDamage(attacker, target, rawDamage, sourceText) {
  if (!target.alive) return 0;
  if (!attemptHit(attacker, target, sourceText)) return 0;

  const damage = calculateDamage(rawDamage, target);
  let remaining = damage;

  if (target.shield > 0) {
    const blocked = Math.min(target.shield, remaining);
    target.shield -= blocked;
    remaining -= blocked;
  }

  target.hp = Math.max(0, target.hp - remaining);

  if (remaining > 0) {
    animateHit(target.team);
  }

  if (target.hp <= 0) {
    target.alive = false;
  }

  logCombat(`${attacker.name}: ${sourceText}. Урон: ${damage}.`);
  return damage;
}

function addShield(unit, amount) {
  unit.shield += amount;
  animateHeal(unit.team);
  logCombat(`${unit.name} получает ${amount} щита.`);
}

function applyAtkBuff(unit, value, turns) {
  unit.atkBuffValue = Math.max(unit.atkBuffValue, value);
  unit.atkBuffTurns = Math.max(unit.atkBuffTurns, turns);
  animateHeal(unit.team);
}

function canPlayerAct() {
  return state && !state.gameOver && state.turn === "player" && state.player.alive;
}

function useBasicAttack() {
  if (!canPlayerAct()) return;
  const attacker = state.player;
  const target = state.enemy;
  dealDamage(attacker, target, effectiveAtk(attacker), attacker.basicName);
  gainUlt(attacker, 25);
  gainUlt(target, 8);
  endPlayerAction();
}

function useSkill() {
  if (!canPlayerAct()) return;
  if (!spendEnergy(2)) {
    logCombat("Не хватает энергии для навыка.");
    renderBattle();
    return;
  }

  const attacker = state.player;
  const target = state.enemy;

  if (attacker.cardId === "raiden-deep-absorption") {
    dealDamage(attacker, target, attacker.skillDamage, `Навык «${attacker.skillName}»`);
    applyAtkBuff(attacker, 0.5, 2);
    if (Math.random() < 0.4) {
      target.skipTurns = Math.max(target.skipTurns, 1);
      logCombat(`Эффект «Задыхающийся»: ${target.name} пропустит следующий ход.`);
    }
    gainUlt(attacker, 20);
    gainUlt(target, 8);
    endPlayerAction();
    return;
  }

  if (attacker.cardId === "yoruichi-wet-shunpo") {
    applyAtkBuff(attacker, 0.6, 2);
    attacker.dodgeChance = Math.max(attacker.dodgeChance, 0.4);
    gainUlt(attacker, 20);
    logCombat(`Навык «${attacker.skillName}»: атака ${attacker.name} повышена на 60% на 2 хода, а шанс уклониться от следующей атаки — 40%.`);
    endPlayerAction();
    return;
  }

  dealDamage(attacker, target, attacker.skillDamage, `Навык «${attacker.skillName}»`);
  gainUlt(attacker, 20);
  gainUlt(target, 8);
  endPlayerAction();
}

function useUltimate() {
  if (!canPlayerAct()) return;
  const attacker = state.player;
  const target = state.enemy;

  if (attacker.ult < 100) {
    logCombat("Ульта ещё не заряжена.");
    renderBattle();
    return;
  }

  attacker.ult = 0;

  if (attacker.cardId === "raiden-deep-absorption") {
    dealDamage(attacker, target, attacker.ultimateDamage, `Ульта «${attacker.ultimateName}»`);
    applyAtkBuff(attacker, 0.7, 3);
    target.exposedTurns = Math.max(target.exposedTurns, 3);
    target.exposedMultiplier = Math.max(target.exposedMultiplier || 0, 0.6);
    target.defDownTurns = Math.max(target.defDownTurns, 3);
    target.defDownValue = Math.max(target.defDownValue || 0, 0.4);
    if (Math.random() < 0.5) {
      target.skipTurns = Math.max(target.skipTurns, 1);
      logCombat(`Эффект «Покорность Вечности»: ${target.name} станен на 1 ход.`);
    }
    logCombat(`Ульта «${attacker.ultimateName}»: ${attacker.name} получает +70% к атаке на 3 хода, а цель — +60% входящего урона и -40% защиты на 3 хода.`);
    checkGameOver();

    if (!state.gameOver) {
      state.turn = "enemy";
      renderBattle();
      setTimeout(enemyTurn, 650);
    } else {
      renderBattle();
    }
    return;
  }

  if (attacker.cardId === "yoruichi-wet-shunpo") {
    const burstDamage = attacker.ultimateDamage + Math.round(effectiveAtk(attacker) * 0.45);
    dealDamage(attacker, target, burstDamage, `Ульта «${attacker.ultimateName}»`);
    applyAtkBuff(attacker, 0.6, 3);
    attacker.hasteTurns = Math.max(attacker.hasteTurns, 3);
    target.exposedTurns = Math.max(target.exposedTurns, 2);
    target.exposedMultiplier = Math.max(target.exposedMultiplier || 0, 0.25);
    target.blindTurns = Math.max(target.blindTurns, 2);
    logCombat(`Ульта «${attacker.ultimateName}»: ${attacker.name} получает мощный бафф атаки и скорости на 3 хода, а враг — дебафф «Ослепление Солнцем» на 2 хода.`);
    checkGameOver();

    if (!state.gameOver) {
      state.turn = "enemy";
      renderBattle();
      setTimeout(enemyTurn, 650);
    } else {
      renderBattle();
    }
    return;
  }

  dealDamage(attacker, target, attacker.ultimateDamage, `Ульта «${attacker.ultimateName}»`);
  target.skipTurns += 1;
  state.extraTurnReady = true;
  logCombat(`Ульта «${attacker.ultimateName}»: враг пропустит 1 ход, а ${attacker.name} получает дополнительный ход.`);
  checkGameOver();

  if (!state.gameOver) {
    state.turn = "player";
    state.energy = Math.min(MAX_TEAM_ENERGY, state.energy + 1);
  }

  renderBattle();
}

function useGuard() {
  if (!canPlayerAct()) return;
  addShield(state.player, 30);
  gainUlt(state.player, 15);
  endPlayerAction();
}

function endPlayerAction() {
  checkGameOver();
  if (state.gameOver) {
    renderBattle();
    return;
  }

  state.turn = "enemy";
  renderBattle();
  setTimeout(enemyTurn, 650);
}

function enemyTurn() {
  if (state.gameOver || !state.enemy.alive) return;

  if (state.enemy.skipTurns > 0) {
    state.enemy.skipTurns -= 1;
    logCombat(`${state.enemy.name} пропускает ход из-за эффекта ульты.`);
    state.turn = "player";
    nextRound();
    renderBattle();
    return;
  }

  const enemy = state.enemy;
  const player = state.player;

  if (enemy.ult >= 100) {
    enemy.ult = 0;
    dealDamage(enemy, player, enemy.ultimateDamage, `Ульта «${enemy.ultimateName}»`);
  } else if (state.round >= 2 && Math.random() > 0.35) {
    dealDamage(enemy, player, enemy.skillDamage, `Навык «${enemy.skillName}»`);
    gainUlt(enemy, 20);
  } else {
    dealDamage(enemy, player, enemy.atk, enemy.basicName);
    gainUlt(enemy, 25);
  }

  gainUlt(player, 10);
  checkGameOver();

  if (!state.gameOver) {
    state.turn = "player";
    nextRound();
  }

  renderBattle();
}

function tickUnitDurations(unit) {
  if (unit.atkBuffTurns > 0) {
    unit.atkBuffTurns -= 1;
    if (unit.atkBuffTurns <= 0) {
      unit.atkBuffValue = 0;
    }
  }

  if (unit.exposedTurns > 0) {
    unit.exposedTurns -= 1;
    if (unit.exposedTurns <= 0) {
      unit.exposedMultiplier = 0;
    }
  }
  if (unit.defDownTurns > 0) {
    unit.defDownTurns -= 1;
    if (unit.defDownTurns <= 0) {
      unit.defDownValue = 0;
    }
  }
  if (unit.blindTurns > 0) unit.blindTurns -= 1;
  if (unit.hasteTurns > 0) unit.hasteTurns -= 1;
}

function nextRound() {
  state.round += 1;
  state.energy = Math.min(MAX_TEAM_ENERGY, START_TEAM_ENERGY + state.round - 1);

  state.player.shield = Math.max(0, Math.floor(state.player.shield * 0.35));
  state.enemy.shield = Math.max(0, Math.floor(state.enemy.shield * 0.35));

  tickUnitDurations(state.player);
  tickUnitDurations(state.enemy);
}

function checkGameOver() {
  if (!state.player.alive || !state.enemy.alive) {
    state.gameOver = true;

    if (!state.player.alive && !state.enemy.alive) {
      showResult("Ничья", "Обе карты выбыли одновременно.");
    } else if (state.player.alive) {
      save.gems += 40;
      save.achievement = `${state.player.name}: победа в дуэли`;
      saveProgress();
      renderProfileSummary();
      showResult("Победа!", `${state.player.name} выигрывает дуэль. Получено 40 кристаллов.`);
    } else {
      showResult("Поражение", "Враг победил. Попробуй чаще использовать защиту и прожимать навыки по таймингу.");
    }
  }
}

function showResult(title, text) {
  els.resultTitle.textContent = title;
  els.resultText.textContent = text;
  els.resultModal.classList.remove("hidden");
}

function getBattleActionMeta(unit) {
  if (unit.cardId === "raiden-deep-absorption") {
    return {
      basicTitle: unit.basicName,
      basicDesc: `Наносит ${effectiveAtk(unit)} урона от текущей АТК · +25 ULT`,
      skillTitle: `Навык «${unit.skillName}»`,
      skillDesc: "55 урона · АТК +50% на 2 хода · 40% шанс пропуска хода врага · стоит 2 энергии",
      ultimateTitle: `Ульта «${unit.ultimateName}»`,
      ultimateDesc: "85 урона · АТК +70% на 3 хода · цель получает +60% урона и -40% DEF на 3 хода · 50% шанс стана"
    };
  }

  if (unit.cardId === "yoruichi-wet-shunpo") {
    return {
      basicTitle: unit.basicName,
      basicDesc: `Наносит ${effectiveAtk(unit)} урона от текущей АТК · +25 ULT`,
      skillTitle: `Навык «${unit.skillName}»`,
      skillDesc: "АТК +60% на 2 хода · 40% dodge следующей атаки · стоит 2 энергии",
      ultimateTitle: `Ульта «${unit.ultimateName}»`,
      ultimateDesc: "Мощный удар, бафф АТК/скорости на 3 хода, «Ослепление Солнцем» на 2 хода · нужен 100% ULT"
    };
  }

  return {
    basicTitle: unit.basicName,
    basicDesc: "Наносит урон от АТК · +25 ULT",
    skillTitle: `Навык «${unit.skillName}»`,
    skillDesc: "45 урона · стоит 2 энергии · +20 ULT",
    ultimateTitle: `Ульта «${unit.ultimateName}»`,
    ultimateDesc: "65 урона · запрет хода врагу · нужен 100% ULT"
  };
}

function renderBattlePrep() {
  if (!els.duelPicker) return;

  const cards = duelEligibleCards();
  const selected = getSelectedBattleCard();

  els.duelPicker.innerHTML = "";
  if (els.squadLeadName) {
    els.squadLeadName.textContent = selected.name;
  }

  cards.forEach((card) => {
    const btn = document.createElement("button");
    btn.className = `duel-choice ${getBorderClass(card)} ${selected.id === card.id ? "selected" : ""}`;

    const media = card.image
      ? `<img src="${card.image}" alt="${card.name}">`
      : `<span>${card.icon}</span>`;

    btn.innerHTML = `
      <div class="duel-choice-media">${media}</div>
      <div>
        <h4>${card.name}</h4>
        <p>${rarityNames[card.rarity]} · ${getRoleLabel(card.role, card.subRole)}</p>
        <div class="duel-stats">
          <span class="chip">⚔️ ${card.atkStat}</span>
          <span class="chip">❤️ ${card.hpStat}</span>
          <span class="chip">🛡️ ${card.defStat}</span>
        </div>
      </div>
    `;

    btn.addEventListener("click", () => {
      save.selectedBattleCardId = card.id;
      saveProgress();
      startGame();
    });

    els.duelPicker.appendChild(btn);
  });
}

function renderBattle() {
  if (!state.player) return;

  renderBattlePrep();

  const selectedCard = getCard(state.player.cardId);
  els.playerCombatCard.className = `combatant-card player-side ${getBorderClass(selectedCard)}`;
  els.enemyCombatCard.className = "combatant-card enemy-side";

  els.playerCombatRole.textContent = `Твоя карта · ${getRoleLabel(state.player.role, state.player.subRole)}`;
  els.enemyCombatRole.textContent = `Враг · ${getRoleLabel(state.enemy.role, state.enemy.subRole)}`;

  renderCombatant("player", state.player);
  renderCombatant("enemy", state.enemy);

  els.combatRound.textContent = state.round;
  els.combatTurn.textContent = state.turn === "player" ? "Игрок" : "Враг";
  els.combatEnergy.textContent = state.energy;
  els.combatBigBadge.textContent = state.gameOver
    ? "Бой окончен"
    : state.turn === "player"
      ? "Твой ход"
      : "Ход врага";

  const actionMeta = getBattleActionMeta(state.player);
  els.basicAttackBtn.innerHTML = `<strong>${actionMeta.basicTitle}</strong><small>${actionMeta.basicDesc}</small>`;
  els.skillBtn.innerHTML = `<strong>${actionMeta.skillTitle}</strong><small>${actionMeta.skillDesc}</small>`;
  els.ultimateBtn.innerHTML = `<strong>${actionMeta.ultimateTitle}</strong><small>${actionMeta.ultimateDesc}</small>`;

  const canAct = canPlayerAct();
  els.basicAttackBtn.disabled = !canAct;
  els.skillBtn.disabled = !canAct || state.energy < 2;
  els.ultimateBtn.disabled = !canAct || state.player.ult < 100;
  els.guardBtn.disabled = !canAct;
}

function renderCombatant(side, unit) {
  const prefix = side === "player" ? "player" : "enemy";
  const artEl = els[`${prefix}CombatArt`];

  artEl.innerHTML = unit.image
    ? `<img src="${unit.image}" alt="${unit.name}">`
    : unit.icon;

  els[`${prefix}CombatName`].textContent = unit.name;
  els[`${prefix}CombatHp`].textContent = unit.hp;
  els[`${prefix}CombatMaxHp`].textContent = unit.maxHp;
  els[`${prefix}CombatDef`].textContent = effectiveDef(unit);
  els[`${prefix}CombatUlt`].textContent = unit.ult;
  els[`${prefix}CombatHpFill`].style.width = `${Math.max(0, unit.hp / unit.maxHp) * 100}%`;

  if (side === "player") {
    els.playerCombatAtk.textContent = effectiveAtk(unit);
  }

  const badge = side === "player" ? els.playerStatusBadge : els.enemyStatusBadge;
  const statuses = [];
  if (unit.shield > 0) statuses.push(`Щит ${unit.shield}`);
  if (unit.skipTurns > 0) statuses.push("Пропуск хода");
  if (unit.atkBuffTurns > 0) statuses.push(`АТК ↑ ${unit.atkBuffTurns}`);
  if (unit.dodgeChance > 0) statuses.push(`Dodge ${Math.round(unit.dodgeChance * 100)}%`);
  if (unit.exposedTurns > 0) statuses.push(`Уязвимость +${Math.round((unit.exposedMultiplier || 0.25) * 100)}% · ${unit.exposedTurns}`);
  if (unit.defDownTurns > 0) statuses.push(`DEF ↓ ${Math.round((unit.defDownValue || 0) * 100)}% · ${unit.defDownTurns}`);
  if (unit.blindTurns > 0) statuses.push(`Слепота ${unit.blindTurns}`);
  if (unit.hasteTurns > 0) statuses.push(`Скорость ↑ ${unit.hasteTurns}`);
  badge.textContent = statuses.join(" · ");
  badge.classList.toggle("hidden", statuses.length === 0);
}

function logCombat(message) {
  els.combatLog.textContent = message;
}

function animateHit(team) {
  const el = team === "player" ? els.playerCombatCard : els.enemyCombatCard;
  el.classList.remove("is-hit");
  void el.offsetWidth;
  el.classList.add("is-hit");
}

function animateHeal(team) {
  const el = team === "player" ? els.playerCombatCard : els.enemyCombatCard;
  el.classList.remove("is-heal");
  void el.offsetWidth;
  el.classList.add("is-heal");
}

function renderAll() {
  applyTheme(save.theme);
  renderProfileSummary();
  renderCollection();
  renderAvatarPicker();
  renderThemes();
  renderBattlePrep();
  if (state.player) renderBattle();
}

function renderProfileSummary() {
  const avatar = getCard(save.avatarCardId);
  const stats = rarityStats();

  els.miniAvatar.textContent = avatar.icon;
  els.profileAvatar.textContent = avatar.icon;
  els.profileAvatarName.textContent = avatar.name;
  els.profileName.textContent = save.playerName;
  els.profileDescription.textContent = save.description;
  els.profileAchievement.textContent = save.achievement;
  els.profileTotalCards.textContent = totalCards();
  els.profileRarityStats.textContent =
    `Common ${stats.common} · Rare ${stats.rare} · Epic ${stats.epic} · Legendary ${stats.legendary} · SR ${stats.sr} · SSR ${stats.ssr} · SSR+ ${stats.ssrplus}`;

  els.homePlayerName.textContent = save.playerName;
  els.homePlayerDesc.textContent = save.description;
  els.homeOwnedCount.textContent = totalCards();
  els.gemsText.textContent = save.gems;

  els.homeRarityLine.innerHTML = `
    <span class="rarity-pill">C ${stats.common}</span>
    <span class="rarity-pill">R ${stats.rare}</span>
    <span class="rarity-pill">E ${stats.epic}</span>
    <span class="rarity-pill">L ${stats.legendary}</span>
    <span class="rarity-pill">SR ${stats.sr}</span>
    <span class="rarity-pill">SSR ${stats.ssr}</span>
    <span class="rarity-pill">SSR+ ${stats.ssrplus}</span>
  `;
}

function renderCollection() {
  const filter = els.rarityFilter.value || "all";
  const cards = ownedCards().filter((card) => filter === "all" || card.rarity === filter);
  els.collectionGrid.innerHTML = "";

  if (cards.length === 0) {
    els.collectionGrid.innerHTML = `<article class="panel"><h3>Пусто</h3><p>Таких карт пока нет. Загляни в гачу.</p></article>`;
    return;
  }

  cards.forEach((card) => {
    const item = document.createElement("article");
    item.className = `collection-card clickable-card ${getBorderClass(card)} ${save.avatarCardId === card.id ? "selected" : ""}`;
    item.tabIndex = 0;
    item.setAttribute("role", "button");
    item.setAttribute("aria-label", `Открыть карточку ${card.name}`);
    item.innerHTML = cardTemplate(card, true);
    item.addEventListener("click", () => openCardViewer(card));
    item.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        openCardViewer(card);
      }
    });
    els.collectionGrid.appendChild(item);
  });
}

function renderAvatarPicker() {
  els.avatarPicker.innerHTML = "";
  ownedCards().forEach((card) => {
    const btn = document.createElement("button");
    btn.className = `collection-card ${getBorderClass(card)} ${save.avatarCardId === card.id ? "selected" : ""}`;
    btn.innerHTML = `${cardTemplate(card, true)}<div class="card-stats"><span class="chip">${save.avatarCardId === card.id ? "Выбрана" : "Поставить на аватарку"}</span></div>`;
    btn.addEventListener("click", () => {
      save.avatarCardId = card.id;
      saveProgress();
      renderAll();
    });
    els.avatarPicker.appendChild(btn);
  });
}

function cardTemplate(card, showCopies = false) {
  const art = card.image
    ? `<img class="card-image" src="${card.image}" alt="${card.name}">`
    : `<div class="card-icon">${card.icon}</div>`;

  const collectionStats = card.atkStat
    ? `
      <span class="chip">⚔️ АТК ${card.atkStat}</span>
      <span class="chip">❤️ ЗДР ${card.hpStat}</span>
      <span class="chip">🛡️ ЗЩТ ${card.defStat}</span>
    `
    : `
      <span class="chip">⚡ ${card.cost}</span>
      ${card.attack ? `<span class="chip">⚔️ ${card.attack}</span>` : ""}
      ${card.shield ? `<span class="chip">🛡️ ${card.shield}</span>` : ""}
      ${card.heal ? `<span class="chip">❤️ ${card.heal}</span>` : ""}
      ${card.draw ? `<span class="chip">+${card.draw}</span>` : ""}
    `;

  const lore = card.series
    ? `<p class="card-lore">Серия: ${card.series}<br>Линейка: «<span class="${getLineClass(card)}">${card.line}</span>»</p>`
    : "";

  const skillDescription = card.skillEffectText
    ? card.skillEffectText
    : `наносит ${card.skillDamage || 0} урона.`;

  const ultimateDescription = card.ultimateEffect
    ? `${card.ultimateDamage ? `наносит ${card.ultimateDamage} урона. ` : ""}${card.ultimateEffect}`.trim()
    : `${card.ultimateDamage || 0} урона.`;

  const abilities = card.skillName
    ? `
      <div class="ability-list">
        <div class="ability-line"><strong>${card.normalAttackName}:</strong> базовая атака.</div>
        <div class="ability-line"><strong>Навык «${card.skillName}»:</strong> ${skillDescription}</div>
        <div class="ability-line"><strong>Ульта «${card.ultimateName}»:</strong> ${ultimateDescription}</div>
      </div>
    `
    : "";

  return `
    ${art}
    <h3>${card.name}</h3>
    <p class="rarity-${card.rarity}">${rarityNames[card.rarity]}</p>
    ${lore}
    <p>${card.text}</p>
    <div class="card-stats">
      ${collectionStats}
      ${showCopies ? `<span class="chip">x${card.copies}</span>` : ""}
    </div>
    ${abilities}
  `;
}


function openCardViewer(card) {
  els.viewerImage.src = card.image || "";
  els.viewerImage.alt = `Арт карточки ${card.name}`;
  els.viewerRarity.textContent = rarityNames[card.rarity] || card.rarity || "";
  els.viewerRarity.className = `eyebrow rarity-${card.rarity}`;
  els.viewerName.textContent = card.name;
  els.viewerCopies.textContent = `x${card.copies || save.owned[card.id] || 1}`;
  els.viewerSeries.innerHTML = `Серия: ${card.series || "Без серии"}`;
  els.viewerLine.innerHTML = card.line
    ? `Линейка: «<span class="${getLineClass(card)}">${card.line}</span>»`
    : "Линейка: —";
  els.viewerAtk.textContent = card.atkStat || card.attack || 0;
  els.viewerHp.textContent = card.hpStat || "—";
  els.viewerDef.textContent = card.defStat || card.shield || 0;
  els.viewerText.textContent = card.text || "Описание отсутствует.";

  els.viewerNormalName.textContent = card.normalAttackName || "Обычная атака";
  els.viewerNormalDesc.textContent = card.atkStat
    ? `Наносит базовый урон. Показатель атаки: ${card.atkStat}.`
    : `Базовый боевой эффект карты.`;

  els.viewerSkillName.textContent = `Навык «${card.skillName || "—"}»`;
  els.viewerSkillDesc.textContent = card.skillName
    ? (card.skillEffectText || `Наносит ${card.skillDamage || 0} урона.`)
    : "Особый навык отсутствует.";

  els.viewerUltName.textContent = `Ульта «${card.ultimateName || "—"}»`;
  els.viewerUltDesc.textContent = card.ultimateName
    ? `${card.ultimateDamage ? `Наносит ${card.ultimateDamage} урона. ` : ""}${card.ultimateEffect || ""}`.trim()
    : "Ультимативное умение отсутствует.";

  els.cardViewer.classList.remove("hidden");
  document.body.style.overflow = "hidden";
}

function closeCardViewer() {
  els.cardViewer.classList.add("hidden");
  document.body.style.overflow = "";
}

function renderThemes() {
  els.themeGrid.innerHTML = "";
  themes.forEach((theme) => {
    const btn = document.createElement("button");
    btn.className = `theme-card ${save.theme === theme.id ? "active-theme" : ""}`;
    btn.style.setProperty("--preview-a", theme.a);
    btn.style.setProperty("--preview-b", theme.b);
    btn.innerHTML = `
      <div class="theme-preview"></div>
      <div>
        <h4>${theme.name}</h4>
        <p>${theme.description}</p>
      </div>
      <span class="chip">${save.theme === theme.id ? "ON" : "Выбрать"}</span>
    `;
    btn.addEventListener("click", () => {
      save.theme = theme.id;
      saveProgress();
      renderAll();
    });
    els.themeGrid.appendChild(btn);
  });
}

function applyTheme(themeId) {
  document.body.dataset.theme = themeId || "standard";
}

function rollRarity() {
  const roll = Math.random() * 100;
  let total = 0;
  for (const [rarity, weight] of rarityWeights) {
    total += weight;
    if (roll <= total) return rarity;
  }
  return "common";
}

function rollGacha() {
  const cost = 100;
  if (save.gems < cost) {
    els.gachaResult.className = "gacha-result panel";
    els.gachaResult.innerHTML = `<h3>Не хватает кристаллов</h3><p>Нужно ${cost}, сейчас ${save.gems}.</p>`;
    return;
  }

  save.gems -= cost;
  const rarity = rollRarity();
  const pool = baseCards.filter((card) => card.rarity === rarity);
  const card = pool[Math.floor(Math.random() * pool.length)];
  save.owned[card.id] = (save.owned[card.id] || 0) + 1;
  save.achievement = rarity === "ssrplus"
    ? "SSR+-призыв"
    : rarity === "ssr"
      ? "SSR-призыв"
      : rarity === "legendary"
        ? "Легендарный призыв"
        : "Призыв карты";
  saveProgress();

  els.gachaResult.className = `gacha-result collection-card ${getBorderClass(card)}`;
  els.gachaResult.innerHTML = `
    <p class="eyebrow">Получена карта</p>
    ${cardTemplate({ ...card, copies: save.owned[card.id] }, true)}
  `;

  renderAll();
}

function showScreen(screenName) {
  document.querySelectorAll(".screen").forEach((screen) => screen.classList.remove("active"));
  document.querySelector(`#screen-${screenName}`).classList.add("active");

  document.querySelectorAll(".nav-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.screen === screenName);
  });
}

function resetProgress() {
  const ok = confirm("Сбросить весь тестовый прогресс?");
  if (!ok) return;
  save = defaultSave();
  saveProgress();
  startGame();
  renderAll();
  showScreen("home");
}

document.querySelectorAll(".nav-btn").forEach((btn) => {
  btn.addEventListener("click", () => showScreen(btn.dataset.screen));
});

els.enterGameBtn.addEventListener("click", () => {
  els.ageGate.classList.add("hidden");
  localStorage.setItem("neonMuseAgeGate", "ok");
});

els.quickNewBattleBtn.addEventListener("click", () => {
  showScreen("battle");
  startGame();
});

els.newGameBtn.addEventListener("click", startGame);
els.restartBtn.addEventListener("click", startGame);
els.basicAttackBtn.addEventListener("click", useBasicAttack);
els.skillBtn.addEventListener("click", useSkill);
els.ultimateBtn.addEventListener("click", useUltimate);
els.guardBtn.addEventListener("click", useGuard);
els.rollGachaBtn.addEventListener("click", rollGacha);
els.rarityFilter.addEventListener("change", renderCollection);
els.resetProgressBtn.addEventListener("click", resetProgress);
els.closeCardViewerBtn.addEventListener("click", closeCardViewer);
els.cardViewerBackdrop.addEventListener("click", closeCardViewer);
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !els.cardViewer.classList.contains("hidden")) {
    closeCardViewer();
  }
});

if (localStorage.getItem("neonMuseAgeGate") === "ok") {
  els.ageGate.classList.add("hidden");
}

applyTheme(save.theme);
startGame();
renderAll();
